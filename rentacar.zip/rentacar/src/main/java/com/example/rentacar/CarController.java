package com.example.rentacar;

import jakarta.validation.Valid;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cars")
public class CarController {

    public record Quote(long days, BigDecimal dailyRate, BigDecimal total) { }

    private final CarRepository cars;
    private final PricingService pricing;

    public CarController(CarRepository cars, PricingService pricing) {
        this.cars = cars;
        this.pricing = pricing;
    }

    @GetMapping
    public List<Car> list() { return cars.findAll(); }

    @GetMapping("/available")
    public List<Car> available(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate start,
                               @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate end) {
        if (end.isBefore(start)) throw new BusinessRuleException("End date must be on or after the start date");
        return cars.findAvailable(start, end, CarStatus.AVAILABLE, BookingStatus.ACTIVE);
    }

    @GetMapping("/{id}/quote")
    public Quote quote(@PathVariable Long id,
                       @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate start,
                       @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate end) {
        if (end.isBefore(start)) throw new BusinessRuleException("End date must be on or after the start date");
        Car c = cars.findById(id).orElseThrow(() -> new NotFoundException("Car", id));
        return new Quote(pricing.days(start, end), c.getDailyRate(), pricing.total(c.getDailyRate(), start, end));
    }

    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public Car create(@Valid @RequestBody Car car) { return cars.save(car); }

    @PutMapping("/{id}")
    public Car update(@PathVariable Long id, @Valid @RequestBody Car in) {
        Car c = cars.findById(id).orElseThrow(() -> new NotFoundException("Car", id));
        c.setMake(in.getMake());
        c.setModel(in.getModel());
        c.setYear(in.getYear());
        c.setPlate(in.getPlate());
        c.setCategory(in.getCategory());
        c.setDailyRate(in.getDailyRate());
        c.setStatus(in.getStatus());
        return cars.save(c);
    }

    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        if (!cars.existsById(id)) throw new NotFoundException("Car", id);
        cars.deleteById(id);
    }
}
