package com.example.rentacar;

import java.math.BigDecimal;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/** Loads a small demo fleet on first start so the app is not empty. */
@Component
public class DataSeeder implements CommandLineRunner {

    private final CarRepository cars;
    private final CustomerRepository customers;

    public DataSeeder(CarRepository cars, CustomerRepository customers) {
        this.cars = cars;
        this.customers = customers;
    }

    @Override
    public void run(String... args) {
        if (cars.count() > 0) return;
        add("Toyota", "Yaris", 2023, "DL-01-1001", CarCategory.ECONOMY, "35.00");
        add("Honda", "City", 2022, "DL-01-1002", CarCategory.SEDAN, "48.00");
        add("Hyundai", "Creta", 2024, "DL-01-1003", CarCategory.SUV, "65.00");
        add("Toyota", "Innova", 2023, "DL-01-1004", CarCategory.VAN, "72.00");
        add("BMW", "5 Series", 2024, "DL-01-1005", CarCategory.LUXURY, "160.00");
        add("Maruti", "Swift", 2021, "DL-01-1006", CarCategory.ECONOMY, "30.00");

        Customer c = new Customer();
        c.setName("Asha Rao");
        c.setEmail("asha@example.com");
        c.setPhone("+91 90000 00001");
        c.setLicenseNo("TS09-2020-11223");
        customers.save(c);
    }

    private void add(String make, String model, int year, String plate, CarCategory cat, String rate) {
        Car car = new Car();
        car.setMake(make); car.setModel(model); car.setYear(year); car.setPlate(plate);
        car.setCategory(cat); car.setDailyRate(new BigDecimal(rate));
        cars.save(car);
    }
}
