package com.example.rentacar;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    public record Stats(long totalCars, long inMaintenance, long rentedToday, long availableToday,
                        long activeBookings, BigDecimal revenue, double utilizationPercent) { }

    private final CarRepository cars;
    private final BookingRepository bookings;

    public DashboardController(CarRepository cars, BookingRepository bookings) {
        this.cars = cars;
        this.bookings = bookings;
    }

    @GetMapping
    public Stats stats() {
        long total = cars.count();
        long maintenance = cars.countByStatus(CarStatus.MAINTENANCE);
        long rented = bookings.countRentedOn(LocalDate.now(), BookingStatus.ACTIVE);
        long available = Math.max(0, total - maintenance - rented);
        double utilization = total == 0 ? 0 : Math.round(rented * 1000.0 / total) / 10.0;
        return new Stats(total, maintenance, rented, available,
                bookings.countByStatus(BookingStatus.ACTIVE),
                bookings.revenue(BookingStatus.CANCELLED), utilization);
    }
}
