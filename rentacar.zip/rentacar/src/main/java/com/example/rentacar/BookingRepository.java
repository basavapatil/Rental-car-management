package com.example.rentacar;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findAllByOrderByStartDateDesc();

    @Query("""
        select count(b) > 0 from Booking b
        where b.car.id = :carId and b.status = :active
          and b.startDate <= :end and b.endDate >= :start""")
    boolean existsOverlap(@Param("carId") Long carId, @Param("start") LocalDate start,
                          @Param("end") LocalDate end, @Param("active") BookingStatus active);

    long countByStatus(BookingStatus status);

    @Query("select count(distinct b.car.id) from Booking b where b.status = :active and b.startDate <= :d and b.endDate >= :d")
    long countRentedOn(@Param("d") LocalDate d, @Param("active") BookingStatus active);

    @Query("select coalesce(sum(b.totalPrice), 0) from Booking b where b.status <> :cancelled")
    BigDecimal revenue(@Param("cancelled") BookingStatus cancelled);
}
