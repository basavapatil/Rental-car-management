package com.example.rentacar;

public enum CarStatus { AVAILABLE, MAINTENANCE }
