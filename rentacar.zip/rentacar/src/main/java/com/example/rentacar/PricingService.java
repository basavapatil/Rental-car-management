package com.example.rentacar;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import org.springframework.stereotype.Service;

/** Pricing rules: 10% off for 7+ days, 15% off for 30+ days. Both dates are inclusive. */
@Service
public class PricingService {

    public long days(LocalDate start, LocalDate end) {
        return ChronoUnit.DAYS.between(start, end) + 1;
    }

    public BigDecimal total(BigDecimal dailyRate, LocalDate start, LocalDate end) {
        long days = days(start, end);
        BigDecimal gross = dailyRate.multiply(BigDecimal.valueOf(days));
        BigDecimal discount = days >= 30 ? new BigDecimal("0.15")
                            : days >= 7 ? new BigDecimal("0.10") : BigDecimal.ZERO;
        return gross.subtract(gross.multiply(discount)).setScale(2, RoundingMode.HALF_UP);
    }
}
