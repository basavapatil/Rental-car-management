package com.example.rentacar;

public enum BookingStatus { ACTIVE, COMPLETED, CANCELLED }
