package com.example.rentacar;

import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class BookingService {

    private final BookingRepository bookings;
    private final CarRepository cars;
    private final CustomerRepository customers;
    private final PricingService pricing;

    public BookingService(BookingRepository bookings, CarRepository cars,
                          CustomerRepository customers, PricingService pricing) {
        this.bookings = bookings;
        this.cars = cars;
        this.customers = customers;
        this.pricing = pricing;
    }

    @Transactional(readOnly = true)
    public List<Booking> list() { return bookings.findAllByOrderByStartDateDesc(); }

    public Booking create(BookingRequest req) {
        if (req.endDate().isBefore(req.startDate()))
            throw new BusinessRuleException("End date must be on or after the start date");

        Car car = cars.findById(req.carId()).orElseThrow(() -> new NotFoundException("Car", req.carId()));
        Customer customer = customers.findById(req.customerId())
                .orElseThrow(() -> new NotFoundException("Customer", req.customerId()));

        if (car.getStatus() == CarStatus.MAINTENANCE)
            throw new BusinessRuleException("This car is in maintenance and cannot be booked");
        if (bookings.existsOverlap(car.getId(), req.startDate(), req.endDate(), BookingStatus.ACTIVE))
            throw new BusinessRuleException("This car is already booked for the selected dates");

        Booking b = new Booking();
        b.setCar(car);
        b.setCustomer(customer);
        b.setStartDate(req.startDate());
        b.setEndDate(req.endDate());
        b.setTotalPrice(pricing.total(car.getDailyRate(), req.startDate(), req.endDate()));
        return bookings.save(b);
    }

    public Booking complete(Long id) { return transition(id, BookingStatus.COMPLETED); }
    public Booking cancel(Long id)   { return transition(id, BookingStatus.CANCELLED); }

    private Booking transition(Long id, BookingStatus to) {
        Booking b = bookings.findById(id).orElseThrow(() -> new NotFoundException("Booking", id));
        if (b.getStatus() != BookingStatus.ACTIVE)
            throw new BusinessRuleException("Only active bookings can be changed");
        b.setStatus(to);
        return b;
    }
}
