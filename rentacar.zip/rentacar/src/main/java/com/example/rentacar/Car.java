package com.example.rentacar;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
public class Car {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Make is required")
    private String make;

    @NotBlank(message = "Model is required")
    private String model;

    @Min(value = 2000, message = "Year must be 2000 or later")
    private int year;

    @NotBlank(message = "Plate number is required")
    @Column(unique = true)
    private String plate;

    @NotNull(message = "Category is required")
    @Enumerated(EnumType.STRING)
    private CarCategory category;

    @NotNull(message = "Daily rate is required")
    @DecimalMin(value = "1.00", message = "Daily rate must be at least 1.00")
    private BigDecimal dailyRate;

    @Enumerated(EnumType.STRING)
    private CarStatus status = CarStatus.AVAILABLE;
}
