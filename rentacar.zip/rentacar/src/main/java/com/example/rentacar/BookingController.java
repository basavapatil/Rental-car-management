package com.example.rentacar;

import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingService service;

    public BookingController(BookingService service) { this.service = service; }

    @GetMapping
    public List<Booking> list() { return service.list(); }

    @PostMapping @ResponseStatus(HttpStatus.CREATED)
    public Booking create(@Valid @RequestBody BookingRequest req) { return service.create(req); }

    @PostMapping("/{id}/return")
    public Booking complete(@PathVariable Long id) { return service.complete(id); }

    @PostMapping("/{id}/cancel")
    public Booking cancel(@PathVariable Long id) { return service.cancel(id); }
}
