package com.example.rentacar;

public enum CarCategory { ECONOMY, SEDAN, SUV, LUXURY, VAN }
