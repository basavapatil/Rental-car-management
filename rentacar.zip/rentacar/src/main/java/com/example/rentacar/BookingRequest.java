package com.example.rentacar;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

public record BookingRequest(
        @NotNull(message = "Car is required") Long carId,
        @NotNull(message = "Customer is required") Long customerId,
        @NotNull(message = "Start date is required") @FutureOrPresent(message = "Start date cannot be in the past") LocalDate startDate,
        @NotNull(message = "End date is required") LocalDate endDate) { }
