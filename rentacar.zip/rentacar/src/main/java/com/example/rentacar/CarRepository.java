package com.example.rentacar;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CarRepository extends JpaRepository<Car, Long> {

    long countByStatus(CarStatus status);

    /** Cars that are in service and have no active booking overlapping [start, end]. */
    @Query("""
        select c from Car c
        where c.status = :ok
          and not exists (
            select b.id from Booking b
            where b.car = c and b.status = :active
              and b.startDate <= :end and b.endDate >= :start)
        order by c.dailyRate""")
    List<Car> findAvailable(@Param("start") LocalDate start, @Param("end") LocalDate end,
                            @Param("ok") CarStatus ok, @Param("active") BookingStatus active);
}
