package com.example.rentacar;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;

class PricingServiceTest {

    private final PricingService pricing = new PricingService();
    private final LocalDate start = LocalDate.of(2030, 1, 1);

    @Test
    void countsBothEndDatesAsRentalDays() {
        assertEquals(3, pricing.days(start, start.plusDays(2)));
    }

    @Test
    void noDiscountUnderSevenDays() {
        assertEquals(new BigDecimal("300.00"), pricing.total(new BigDecimal("50"), start, start.plusDays(5)));
    }

    @Test
    void tenPercentOffFromSevenDays() {
        assertEquals(new BigDecimal("630.00"), pricing.total(new BigDecimal("100"), start, start.plusDays(6)));
    }

    @Test
    void fifteenPercentOffFromThirtyDays() {
        assertEquals(new BigDecimal("2550.00"), pricing.total(new BigDecimal("100"), start, start.plusDays(29)));
    }
}
